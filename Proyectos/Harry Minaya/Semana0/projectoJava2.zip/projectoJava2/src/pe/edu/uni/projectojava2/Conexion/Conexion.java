
package pe.edu.uni.projectojava2.Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Conexion {
    
    Connection con;
    
    public Conexion(){
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/proyectojava2","root","");
            
        } catch (Exception e) {
            System.err.println("Error"+e);
        }
    
    }
   
    
}
