/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.edu.uni.projectojava2.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author amv
 */

public class PruebaConexion {
    public static void main(String[] args) {
    Conexion cn=new Conexion();
        Statement st;
        ResultSet rs;
        try {
            st=cn.con.createStatement();
            rs=st.executeQuery("select * from empleado");
            while(rs.next()){
                System.out.println(rs.getString("codemple")+" "+
                                   rs.getString("nomemple")+" "+
                                   rs.getNString("direcemple")+
                                   rs.getNString("teleemple")+" "+
                                   rs.getString("celuemple")+" "+
                                   rs.getString("emailemple"));
            }
             cn.con.close();
        } catch (Exception e) {
        }

    }
}

