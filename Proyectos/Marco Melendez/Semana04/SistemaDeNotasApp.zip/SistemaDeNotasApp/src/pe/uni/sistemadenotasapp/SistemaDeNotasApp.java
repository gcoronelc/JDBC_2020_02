package pe.uni.sistemadenotasapp;

import pe.uni.sistemadenotasapp.view.LogonView;

public class SistemaDeNotasApp {

	public static void main(String[] args) {
		LogonView.main(args);
	}

}
