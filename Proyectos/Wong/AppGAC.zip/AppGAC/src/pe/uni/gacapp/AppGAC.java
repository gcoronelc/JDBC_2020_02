package pe.uni.gacapp;

import pe.uni.gacapp.view.LogonView;

/**
 *
 * @author nwongs
 */
public class AppGAC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LogonView.main(args);
    }
    
}
