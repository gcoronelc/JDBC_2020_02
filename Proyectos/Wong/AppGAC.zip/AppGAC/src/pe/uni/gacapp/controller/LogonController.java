package pe.uni.gacapp.controller;

import pe.uni.gacapp.model.EmpleadoModel;
import pe.uni.gacapp.service.LogonService;
import pe.uni.gacapp.util.Session;

/**
 *
 * @author nwongs
 */
public class LogonController {

	private LogonService logonService;

	public LogonController() {
		logonService = new LogonService();
	}
	
	public void validar(String usuario, String clave){
		EmpleadoModel model = logonService.validar(usuario, clave);
		Session.put("USUARIO", model);
	}
	
}

