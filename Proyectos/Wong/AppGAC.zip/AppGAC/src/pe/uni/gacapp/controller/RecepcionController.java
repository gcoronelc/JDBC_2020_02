package pe.uni.gacapp.controller;

import java.util.List;
import java.util.Map;
import pe.uni.gacapp.service.RecepcionService;

/**
 *
 * @author nwongs
 */
public class RecepcionController {
	private RecepcionService recepcionService;

	public RecepcionController() {
		recepcionService = new RecepcionService();
	}
	
        public void registraRecepcion(String proveedor, String Serie, double nroDoc,
                                    String Placa, double nroJabas,
                                    double unidades, double pesoBruto, double pesoTara, double pesoNeto){
                                    recepcionService.regitrarRecepcion(proveedor, Serie, nroDoc,
                                    Placa, nroJabas, unidades, pesoBruto, pesoTara, pesoNeto, "0004");
        }
            
	public List<Map<String,?>> getMovimientos(String proveedor){
		return recepcionService.getMovimientos(proveedor);
	} 
                
}
