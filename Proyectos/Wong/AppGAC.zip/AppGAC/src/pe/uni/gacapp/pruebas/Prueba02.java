/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.uni.gacapp.pruebas;

import java.sql.Connection;
import java.sql.Statement;
import pe.uni.gacapp.db.AccesoDB;

/**
 *
 * @author nwongs
 */
public class Prueba02 {
	public static void main(String[] args) {
		Connection cn = null;
		try {
			cn = AccesoDB.getConnection();
			Statement stm = cn.createStatement();
			cn.setAutoCommit(false); // Inicio de Tx
			stm.execute("insert into bdnwong.moneda(chr_monecodigo,vch_monedescripcion) values( '03', 'Euros' )");
			//stm.execute("insert into moneda(chr_monecodigo,vch_monedescripcion) values( '79', 'EL INTI' )");
			stm.close();
			cn.commit(); // Confirma la Tx
			System.out.println("Proceso ok.");
		} catch (Exception e) {
			e.printStackTrace();
			try {
				cn.rollback(); // Cancela la Tx
			} catch (Exception e1) {
			}
		} finally{
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		
	}
    
}
