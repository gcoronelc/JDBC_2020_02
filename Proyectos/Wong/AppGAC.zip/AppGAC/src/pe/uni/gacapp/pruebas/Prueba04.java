/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.uni.gacapp.pruebas;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import pe.uni.gacapp.db.AccesoDB;

/**
 *
 * @author nwongs
 */
public class Prueba04 {
	
	public static void main(String[] args) {
		Connection cn = null;
		try {
			cn = AccesoDB.getConnection();
			Statement stm = cn.createStatement();
			String sql = "select * from bdnwong.moneda";
			ResultSet rs = stm.executeQuery(sql);
			while( rs.next() ){
				String codigo = rs.getString("chr_monecodigo");
				String descripcion = rs.getString("vch_monedescripcion");
				System.out.println(codigo + " - " + descripcion);
			}
			rs.close();
			stm.close();
			System.out.println("Proceso ok.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		
	}
    
}
