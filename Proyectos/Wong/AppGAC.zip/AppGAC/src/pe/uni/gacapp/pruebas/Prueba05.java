/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.uni.gacapp.pruebas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import pe.uni.gacapp.db.AccesoDB;

/**
 *
 * @author nwongs
 */
public class Prueba05 {
	
	public static void main(String[] args) {
		Connection cn = null;
		try {
			cn = AccesoDB.getConnection();
			String sql = "select * from bdnwong.moneda where upper(vch_monedescripcion) like ?";
			PreparedStatement pstm = cn.prepareStatement(sql);
			pstm.setString(1, "%SOLES%");
			ResultSet rs = pstm.executeQuery();
			while( rs.next() ){
				String codigo = rs.getString("chr_monecodigo");
				String descripcion = rs.getString("vch_monedescripcion");
				System.out.println(codigo + " - " + descripcion);
			}
			rs.close();
			pstm.close();
			System.out.println("Proceso ok.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		
	}
    
}
