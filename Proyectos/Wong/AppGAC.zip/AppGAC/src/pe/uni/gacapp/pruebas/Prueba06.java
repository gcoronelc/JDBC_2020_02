/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.uni.gacapp.pruebas;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLType;
import pe.uni.gacapp.db.AccesoDB;

/**
 *
 * @author nwongs
 */
public class Prueba06 {

    public static void main(String[] args) {
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
            String sql = "{call usp_sumar(?,?,?)}";
            CallableStatement cstm = cn.prepareCall(sql);
            cstm.setDouble(1, 45.78);
            cstm.setDouble(2, 56.23);
            cstm.registerOutParameter(3, java.sql.Types.DECIMAL);
            cstm.executeUpdate();
            double suma = cstm.getDouble(3);
            cstm.close();
            System.out.println("Suna: " + suma);
            System.out.println("Proceso ok.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }

    }

}
