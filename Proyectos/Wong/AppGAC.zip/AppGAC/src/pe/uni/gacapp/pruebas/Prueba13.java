/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.uni.gacapp.pruebas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import oracle.net.aso.r;
import pe.uni.gacapp.db.AccesoDB;
import pe.uni.gacapp.service.RecepcionService;

/**
 *
 * @author nwongs
 */
public class Prueba13 {

    public static void main(String[] args) {
        try {
            RecepcionService recepcionService = new RecepcionService();
            List<Map<String, ?>> lista = recepcionService.getMovimientos("016");
            for (Map<String, ?> r : lista) {
                String serieComp = r.get("seriecomp").toString();
                String nroComp = r.get("nrocomp").toString();
                String fecha = r.get("fechaemision").toString();
                String placa = r.get("idplaca").toString();
                String jabas = r.get("totenvases").toString();
                System.out.println(serieComp + " - " + nroComp + " - " + fecha + " - " + placa + " - " + jabas);
            }
            System.out.println("Proceso ok.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
    }

}
