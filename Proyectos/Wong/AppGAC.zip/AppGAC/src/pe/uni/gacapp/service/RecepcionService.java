package pe.uni.gacapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import pe.uni.gacapp.db.AccesoDB;
/**
 *
 * @author nwongs
 */
public class RecepcionService {
    
    public void regitrarRecepcion(String proveedor, String Serie, double nroDoc,
                                    String Placa, double nroJabas,
                                    double unidades, double pesoBruto, double pesoTara, double pesoNeto, 
                                    String empleado){
        Connection cn = null;
        String sql = "";
        PreparedStatement pstm;
        ResultSet rs = null;   
        int cont = 0;
        int contReg = 0;
        try{
            cn = AccesoDB.getConnection();
            cn.setAutoCommit(false);
            // Validar el Cantidad de jabas
            if (nroJabas <= 0.0) {
            throw new Exception("Numero de Jabas debe ser positivo, mayor a 0.0.");
            }
            
            // Validar el empleado
            sql = "select count(1) cont from bdnwong.empleado where chr_emplcodigo = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, empleado);
            rs = pstm.executeQuery();
            rs.next();
            cont = rs.getInt(1);
            rs.close();
            pstm.close();
            if (cont == 0) {
                    throw new Exception("Empleado no existe.");
            }
                        
            // Validar Proveedor
            sql = "select count(1) cont from bdnwong.Maeproveedor p where p.Codentidad = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, proveedor);
            rs = pstm.executeQuery();
            rs.next();
            cont = rs.getInt(1);
            rs.close();
            pstm.close();
            if (cont == 0) {
                    throw new Exception("Proveedor no existe.");
            }   
            rs.close();
            pstm.close();            
            // Validar contador de registros
            sql = "select coalesce(Max(idreg),0) contReg from BDNWONG.MOVOPRECEPCIONCAB" ;
            pstm = cn.prepareStatement(sql);
            rs = pstm.executeQuery();
            rs.next();
            contReg = rs.getInt(1);
            contReg++;
            rs.close();
            pstm.close();
            if (cont == 0) {
                    throw new Exception("No existe la tabla no MOVOPRECEPCIONCAB.");
            }   
            rs.close();
            pstm.close();              

            // Actualizar Stock
 /*           saldo += importe;
            cont++;
            sql = "update cuenta set dec_cuensaldo=?, int_cuencontmov=? where chr_cuencodigo = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setDouble(1, saldo);
            pstm.setInt(2, cont);
            pstm.setString(3, cuenta);
            pstm.executeUpdate();
            pstm.close();           */ 
            // Registrar movimiento
            sql = "insert into BDNWONG.MOVOPRECEPCIONCAB(codempresa,codzona,idreg,codentidad,tipocomp,seriecomp,nrocomp,fechaemision,idtipomov,idplaca,totenvases,totund,totpbruto,totptara, totpneto,fechacreacion,flagestado,periodo,usrcreador)values('1','002',?,?,'07',?,?,sysdate,'R1',?,?,?,?,?,?,sysdate,'1','2020',?)";
          /*  sql = "insert into BDNWONG.MOVOPDISTRIBUCIONCAB(codempresa,codzona,idreg,codentidad,tipocomp,seriecomp,nrocomp," 
                                       + "fechaemision,idtipomov,idplaca,totenvases,totund,totpbruto,totptara," 
                                       + "totpneto,fechacreacion,flagestado,periodo,usrcreador)" 
                                       + "values('1','002',2,'008','07','001',254,sysdate,'R1','FTP-095',100,800,3450,700,2680,sysdate,'1','2020','0001')";*/
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, contReg);
            pstm.setString(2, proveedor);
            pstm.setString(3, Serie);
            pstm.setDouble(4, nroDoc);
            pstm.setString(5, Placa);
            pstm.setDouble(6, nroJabas);
            pstm.setDouble(7, unidades);
            pstm.setDouble(8, pesoBruto);
            pstm.setDouble(9, pesoTara);
            pstm.setDouble(10, pesoNeto);
            pstm.setString(11, empleado);            
            pstm.executeUpdate();
            pstm.close();
            cn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try{
                cn.rollback();
            } catch (Exception e1){    
            }
            throw new RuntimeException("Error en el proceso. " + e.getMessage());
        } finally{
            try{
                cn.close();
            } catch (Exception e){ 
            }
        }
        
    }
    
    public List<Map<String, ?>> getMovimientos(String proveedor) {
        List<Map<String, ?>> lista = new ArrayList<>();
        Connection cn = null;
        try {
                cn = AccesoDB.getConnection();             
                String sql = "select Codentidad, Seriecomp, Nrocomp, Fechaemision, Idplaca, "
                        + " Totenvases, Totund, Totpbruto, Totptara, Totpneto " 
                        + "from BDNWONG.MOVOPRECEPCIONCAB where Codentidad = ?";
                PreparedStatement pstm = cn.prepareStatement(sql);
                pstm.setString(1, proveedor);
                ResultSet rs = pstm.executeQuery();
                lista = JdbcUtil.rsToList(rs);
                rs.close();
                pstm.close();
        } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
        } finally {
                try {
                        cn.close();
                } catch (Exception e) {
                }
        }
        return lista;        
        
    }
    
}
